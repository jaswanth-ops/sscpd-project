# Skills4Future_Project
Projects under the Advanced Track in AI &amp; Green Skills with Skills4Future
